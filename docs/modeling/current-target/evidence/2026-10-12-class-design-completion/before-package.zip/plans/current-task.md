# Current task pointer

**Status:** DONE — detailed DOM-01 completeness documentation review only.
**Approval:** [user-authorized review](approved/2026-10-12-class-completeness-review-APPROVED.md).
**Completed task:** [archive](archive/2026-10-12-class-completeness-review-DONE.md).
**Deliverable:** [all23 classifier review + concrete correction proposal](../docs/modeling/current-target/class-completeness-review-2026-10-12.md).
**Evidence:** [audit](../docs/modeling/current-target/evidence/2026-10-12-class-completeness/verification.json), [inventory](../docs/modeling/current-target/evidence/2026-10-12-class-completeness/inventory.json), [entry capture](../docs/modeling/current-target/evidence/2026-10-12-class-completeness/entry-pointer.zip).

Conclusion: conceptual overview with minimal attributes; insufficient as detailed class design. Five empty classes; source/native members match. No canonical/native diagram or business correction applied. All44 pages and1,041 protected files unchanged; logs recorded, no staging/commit. Source-backed additions and naming/type/operation choices are proposals requiring a separately authorized correction scope.

Prior Activity layout and DOM readability remain DONE in their archives. Prior insertion drift remains separately [REVIEW](archive/2026-10-12-add-report-usecases-to-native-drawio-REVIEW-CAPTURE.md). Physical design PROPOSED, liveDB unverified; implementation/physical approval gates unchanged. No follow-on work active.


## Active directly authorized task: full Activity refinement

**Status:** TESTING

# Full Activity layout refinement — preserve concurrent document changes

**Approval:** direct user request 2026-10-12: “kh chỉnh full à có mấy cái trông vẫn khá xấu ... đang có 1 cái cập nhật song song ... kiểm tra lại xem”; save clarification: “Kiểm tra rồi lưu an toàn vào file chính”. Bounded diagram layout only.
**Scope:** all eight active native ACT-01/02/03/04/06/07/08/09 pages; prioritize ACT-03/06/04 and screenshot ACT-01. Full layout refinement, not just enlarging existing coordinates. Separate candidate and visual exports first; compare-and-save only the eight current pages into the latest primary bundle after validation. Preserve concurrent DOM-01 and all other current raw pages.
**Permitted:** consistent wrapped boxes, lane widths, row spacing, compact existing rail geometry, orthogonal connectors and separated branch labels. Preserve every existing label/ID/endpoint/arrow and embedded PUML. Native PNG/SVG and presentation crops in new evidence; current ten-minute script image links; append-only task/test/development/handoff records.
**Read-only:** all PUML and original PlantUML renders/manifests, product/spec/ADR, application/schema/API/DB/migrations, repository scripts/tests, prior evidence/approvals and PPTX. No new UML/product decision, full-bundle builder, staging or commit.
**Review:** previous mechanical expansion kept excessively long join lines and close parallel tracks. Shared bundle is also being edited in the DOM-01 chat. Screenshot matches ACT-01 current layout, not evidence of a lost AD save. Work on entry copy; merge only after AD raw hashes/semantics and latest page list remain compatible. If the same AD page changed externally, stop that page and preserve the conflict rather than overwrite it.
**Acceptance:** all eight layout pages readable; compact join lines, aligned/wrapped boxes, no connector through text; no label/shape clipping. Latest 36 non-AD pages exact at merge, including concurrent DOM-01. Canonical semantics unchanged; inspect actual exports and each difficult region before completion.
**Verification:** entry backup/hashes; separate candidate exports; temporary text-fit/node/route/label/semantic audit; before-save compare, exclusive file save and after-save raw-page audit; latest DOM-01 retained; current script links; diff check/stat, new-file line counts, append-only test/development evidence. Runtime N/A (layout only).
