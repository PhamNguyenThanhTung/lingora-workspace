# Lingora Canonical Product Database

> **Current status: IMPLEMENTING / STAGE A ONLY / NOT DATABASE READY.** Repair authorized under `WP-DB-REMAIN-01` (plans/2026-10-28-database-remaining-repair-spec.md). Preserve all applied migrations. Stage A delivers 5th migration (`20261028000000_product_remaining_repair`), locked storage contracts, corrected preflight gates, full catalog parity contract, and precise smoke machinery. Remote mutations, migrate deploy, seed, and live smoke remain strictly gated for Stage B.

This directory contains the canonical product database schema, ordered migrations, seed scripts, and acceptance smoke for the Lingora platform.
Authority: `plans/2026-10-28-database-remaining-repair-spec.md` and `plans/2026-10-27-product-database-finalize-spec.md`.

## Structure

```
lingora-admin/prisma/product/
├── schema.prisma                       # Canonical 34-table Prisma schema
├── seed.mjs                            # Idempotent configuration and DEV fixture seed (with mismatch rejection)
├── README.md                           # Operations instructions and constraint ownership
└── migrations/
    ├── migration_lock.toml             # PostgreSQL migration lock
    ├── 20261027000000_product_baseline/
    │   └── migration.sql               # Canonical baseline DDL (immutable applied bytes: 69093deb...)
    ├── 20261027010000_product_finalize/
    │   └── migration.sql               # Forward finalization: DB-C1 drop, bounds, freeze, provenance, defaults (b3cea3d3...)
    ├── 20261027020000_product_correction/
    │   └── migration.sql               # Transactional correction: provenance columns, snapshot shape (3a584726...)
    ├── 20261027030000_product_remediation/
    │   └── migration.sql               # Transactional remediation: active revision attempt scope, item deletes (5026899d...)
    └── 20261028000000_product_remaining_repair/
        └── migration.sql               # Remaining repair: restore prior_revision_id/created_at freeze, review row correspondence (8ca114e3...)
```

Generated product client is located at: `lingora-admin/generated/product-client/` (git-ignored, separated from parked fixture client).

## Product Database Operations

All commands target this product schema. Never fall back to Prisma's default root schema.
Credentials reside strictly in Git-ignored `lingora-admin/.env` (mode 0600) and are parsed in memory. No manual shell exports containing passwords or URLs are required.

### 1. Validate Schema
```sh
npm run db:product:validate -w lingora-admin
```
Validates the 34-model product schema offline.

### 2. Generate Product Client
```sh
npm run db:product:generate -w lingora-admin
```
Generates the isolated product Prisma client into `lingora-admin/generated/product-client/`.

### 3. Read-Only Target Preflight
```sh
# Offline target parser check (no network connection made)
node scripts/product-preflight.mjs --static

# Live DEV target preflight
npm run db:product:preflight -w lingora-admin

# Intent-specific preflight checks
node scripts/product-preflight.mjs --intent=migrate
node scripts/product-preflight.mjs --intent=seed
node scripts/product-preflight.mjs --intent=smoke
```
Validates exact project reference `sncfyvpzwedqgwfpffkh`, hostname, user forms, database name `postgres`, absence of overriding query params, provider prerequisites, and finite safe states (`INITIAL_CLEAN`, `UPGRADE_BASELINE`, `UPGRADE_FINALIZE`, `UPGRADE_REMEDIATION`, `UPGRADE_REPAIR`, `REPLAY_REPAIRED`).

### 4. Apply Forward Migration (Dedicated Hosted Supabase DEV Only)
```sh
npm run db:product:migrate -w lingora-admin
```
This wrapper automatically executes preflight first (`intent=migrate`), confirms `UPGRADE_REPAIR` (or `REPLAY_REPAIRED` for replay), runs `prisma migrate deploy --schema prisma/product/schema.prisma`, and verifies that the database transitioned to `REPLAY_REPAIRED`.

### 5. Seed Canonical Configuration
```sh
npm run db:product:seed -w lingora-admin
```
Requires `REPLAY_REPAIRED` state. Idempotently seeds UI locales (`en`, `vi`), CEFR framework, A1-B2 levels, and marked DEV fixture curriculum (`[DEV]` prefix). Runs in a single transaction; detects and rejects any semantic mismatch without overwriting.

### 6. Acceptance Smoke & Parity Verification
```sh
# Offline static smoke checks
npm run db:product:smoke -w lingora-admin -- --static

# Live DEV smoke suite
npm run db:product:smoke -w lingora-admin
```
Requires `REPLAY_REPAIRED` state. Executes target agreement, full authoritative catalog parity assertions against contract, pure rollback mutation probes (CRUD with UPDATE, owned RESTRICT, natural key duplicate, start shape, completion bounds, SRS schedule match, revision review shapes, freeze guards, retired media tombstones), seed idempotency, public access denials, and server DB module path reads. All mutation probes run with unconditional rollback.

---

## Locked Storage Envelopes & Serialization Contract

Per spec §4, the following JSONB envelopes and catalog contracts are locked across migrations, README, and fixtures:

### 1. Assignment History & Review Scope Envelope
Stored in `app.assignment_history.scope_snapshot`, copied to `app.lesson_revisions.assignment_scope_snapshot` on submission, and verified on `app.revision_reviews.assignment_scope_snapshot`:

```json
{
  "schema_version": 1,
  "lesson_id": "<uuid-string-matching-lesson_id>",
  "requirement": {},
  "scope": {}
}
```

- `schema_version`: integer 1.
- `lesson_id`: UUID string matching `content_assignments.lesson_id`.
- `requirement` and `scope`: JSON objects representing configured requirements and scope.
- In `app.revision_reviews`, `NEW.assignment_generation` must match the episode's `scope_generation`, and `NEW.assignment_scope_snapshot` must match the episode's `scope_snapshot`.

### 2. Assessment Version Blueprint Snapshot Envelope
Stored in `app.assessment_versions.blueprint_snapshot`:

```json
{
  "schema_version": 1,
  "blueprint_id": "<uuid-string-matching-blueprint_id>",
  "blueprint_generation": 1,
  "course_id": "<uuid-string-matching-blueprint-course_id>",
  "language_id": "<uuid-string-matching-course-language_id>",
  "framework_id": "<uuid-string-matching-course-framework_id>",
  "purpose": "PLACEMENT | LEVEL_UP",
  "target_level_id": "<uuid-string-or-null>",
  "next_level_id": "<uuid-string-or-null>",
  "coverage_catalog_generation": 1,
  "config": {},
  "coverage": {},
  "requirements": {},
  "coverage_catalog": {}
}
```

- `schema_version`: integer 1.
- `blueprint_id`: UUID string matching `assessment_versions.blueprint_id`.
- `blueprint_generation`: integer matching `assessment_versions.blueprint_generation`.
- `course_id`, `language_id`, `framework_id`, `purpose`, `target_level_id`, `next_level_id`: match the underlying blueprint and parent course records.
- `coverage_catalog_generation`: integer matching blueprint and parent course `coverage_catalog_generation`.
- `config`, `coverage`, `requirements`: JSON objects matching blueprint definition.
- `coverage_catalog`: JSON object matching course `coverage_catalog`.

### 3. Assessment Version Item Coverage Tags Envelope
Stored in `app.assessment_version_items.coverage_tags`:

```json
{
  "topic_ids": ["<topic_id_1>", "<topic_id_2>"],
  "skill_ids": ["<skill_id_1>", "<skill_id_2>"],
  "purpose_tags": ["<purpose_tag_1>"]
}
```

- Must be a JSON object containing text arrays `topic_ids`, `skill_ids`, `purpose_tags`.
- Empty arrays `{ "topic_ids": [], "skill_ids": [], "purpose_tags": [] }` or `{}` are valid when no specific coverage tags are attached.
- Tag IDs must correspond to entries defined in the pinned version's `blueprint_snapshot.coverage_catalog`.

### 4. Course Coverage Catalog Dictionary Access Paths
Stored in `app.courses.coverage_catalog`:

```json
{
  "topics": {
    "<topic_id>": { "id": "<topic_id>", "code": "TOPIC_CODE", "label": { "en": "Topic Name" }, "is_active": true }
  },
  "skills": {
    "<skill_id>": { "id": "<skill_id>", "code": "SKILL_CODE", "label": { "en": "Skill Name" }, "is_active": true, "area_code": "VOCABULARY | GRAMMAR | READING | LISTENING" }
  },
  "purposes": {
    "<purpose_code>": { "code": "WORK", "label": { "en": "Work & Business" }, "is_active": true }
  }
}
```

Empty object `{}` is valid when no custom catalog items are configured.
