-- =============================================================================
-- Migration: 20261028000000_product_remaining_repair
-- Authority: plans/2026-10-28-database-remaining-repair-spec.md
-- Resolves: PRE-01, PRE-02, PRE-03, PRE-04
--           FDB-05 (Freeze Boundaries & Prior Revision / Created At Pins)
--           FDB-06 (Minimal Validated Storage & Assignment Envelope Review Correspondence)
-- Invariants: Retains all 4 applied migrations immutable; transactional BEGIN/COMMIT
--             Local statement & lock timeouts; preflight & postflight assertions
-- =============================================================================

BEGIN;

SET LOCAL statement_timeout = '15s';
SET LOCAL lock_timeout = '5s';

-- -----------------------------------------------------------------------------
-- Step 1: Preflight Assertions (PRE-04)
-- Strict migration history validation and transactional data integrity assertions
-- -----------------------------------------------------------------------------
DO $$
DECLARE
  v_base_ck TEXT := '69093deb1f9ed8d2350fda757a86546044c2a66eb6d58a4cef326928188d9862';
  v_fin_ck TEXT  := 'b3cea3d36ab2072b6ef839b957a96c484f9c79d63e01b13cadd4407e31545f16';
  v_cor_ck TEXT  := '3a5847261839367edd608065be3bcb8359bb11eeaaf7c0f51813231dbc1d9029';
  v_rem_ck TEXT  := '5026899d25e2bfd04bec69e7e74d8c84a71d13ce92344dde3f8999cf4e23dbf6';
  v_rep_name TEXT := '20261028000000_product_remaining_repair';
  v_total_migs INT;
  v_row RECORD;
  v_idx INT := 0;
  v_invalid_rows INT;
BEGIN
  -- 1. Exact migration history count: must be either 4 finished migrations (pre-deploy)
  --    OR 5 migrations where 5th is the current in-progress migration from Prisma.
  SELECT count(*) INTO v_total_migs FROM app._prisma_migrations;
  IF v_total_migs NOT IN (4, 5) THEN
    RAISE EXCEPTION 'Preflight assertion failed: expected 4 or 5 migrations in history, found %', v_total_migs;
  END IF;

  FOR v_row IN SELECT migration_name, checksum, finished_at, rolled_back_at 
                 FROM app._prisma_migrations 
                ORDER BY started_at ASC LOOP
    v_idx := v_idx + 1;
    IF v_row.rolled_back_at IS NOT NULL THEN
      RAISE EXCEPTION 'Preflight assertion failed: migration % is rolled back', v_row.migration_name;
    END IF;

    IF v_idx = 1 THEN
      IF v_row.migration_name != '20261027000000_product_baseline' OR v_row.checksum != v_base_ck OR v_row.finished_at IS NULL THEN
        RAISE EXCEPTION 'Preflight assertion failed: baseline migration verification failed';
      END IF;
    ELSIF v_idx = 2 THEN
      IF v_row.migration_name != '20261027010000_product_finalize' OR v_row.checksum != v_fin_ck OR v_row.finished_at IS NULL THEN
        RAISE EXCEPTION 'Preflight assertion failed: finalize migration verification failed';
      END IF;
    ELSIF v_idx = 3 THEN
      IF v_row.migration_name != '20261027020000_product_correction' OR v_row.checksum != v_cor_ck OR v_row.finished_at IS NULL THEN
        RAISE EXCEPTION 'Preflight assertion failed: correction migration verification failed';
      END IF;
    ELSIF v_idx = 4 THEN
      IF v_row.migration_name != '20261027030000_product_remediation' OR v_row.checksum != v_rem_ck OR v_row.finished_at IS NULL THEN
        RAISE EXCEPTION 'Preflight assertion failed: remediation migration verification failed';
      END IF;
    ELSIF v_idx = 5 THEN
      IF v_row.migration_name != v_rep_name THEN
        RAISE EXCEPTION 'Preflight assertion failed: unexpected 5th migration name % (expected %)', v_row.migration_name, v_rep_name;
      END IF;
    END IF;
  END LOOP;

  -- 2. Exact 34 product tables count (29 app + 5 app_private)
  IF (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'app' AND table_name != '_prisma_migrations') != 29 THEN
    RAISE EXCEPTION 'Preflight assertion failed: app tables count is not 29';
  END IF;
  IF (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'app_private') != 5 THEN
    RAISE EXCEPTION 'Preflight assertion failed: app_private tables count is not 5';
  END IF;

  -- 3. Transactional data integrity assertions (PRE-04)
  -- 3a. Check no submitted lesson revisions lack required submission facts
  SELECT count(*) INTO v_invalid_rows
    FROM app.lesson_revisions
   WHERE status IN ('IN_REVIEW', 'CHANGES_REQUESTED', 'APPROVED', 'PUBLISHED')
     AND (submitted_at IS NULL OR submitted_by IS NULL OR 
          submitted_assignment_generation IS NULL OR assignment_scope_snapshot IS NULL);
  IF v_invalid_rows > 0 THEN
    RAISE EXCEPTION 'Preflight data gate failed: % submitted lesson revisions lack required submission facts', v_invalid_rows;
  END IF;

  -- 3b. Check no assessment results have invalid points bounds
  SELECT count(*) INTO v_invalid_rows
    FROM app.assessment_results
   WHERE raw_points < 0 OR possible_points <= 0 OR raw_points > possible_points;
  IF v_invalid_rows > 0 THEN
    RAISE EXCEPTION 'Preflight data gate failed: % assessment results violate points bounds', v_invalid_rows;
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- Step 2: PRE-03 — Assignment History Scope Snapshot Guard at Episode Creation
-- Validates requirement, scope, lesson_id, generation, and safe UUID/integer casts
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.guard_assignment_history_scope_snapshot()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_assign_lesson_id UUID;
  v_assign_req JSONB;
  v_assign_scope JSONB;
  v_assign_gen BIGINT;
  v_s JSONB := NEW.scope_snapshot;
  v_ver_str TEXT;
  v_lesson_str TEXT;
BEGIN
  IF v_s IS NULL OR jsonb_typeof(v_s) != 'object' THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot must be a JSON object'
      USING ERRCODE = 'check_violation';
  END IF;

  -- 1. Envelope required keys check
  IF NOT (v_s ? 'schema_version') OR
     NOT (v_s ? 'lesson_id') OR
     NOT (v_s ? 'requirement') OR
     NOT (v_s ? 'scope') THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot missing required envelope keys (schema_version, lesson_id, requirement, scope)'
      USING ERRCODE = 'check_violation';
  END IF;

  -- 2. Validate types and format BEFORE any cast (PRE-03)
  IF jsonb_typeof(v_s->'schema_version') != 'number' THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot schema_version must be a number'
      USING ERRCODE = 'check_violation';
  END IF;

  v_ver_str := v_s->>'schema_version';
  IF v_ver_str !~ '^[0-9]+$' OR v_ver_str::int != 1 THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot schema_version must be integer 1'
      USING ERRCODE = 'check_violation';
  END IF;

  IF jsonb_typeof(v_s->'lesson_id') != 'string' THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot lesson_id must be a string'
      USING ERRCODE = 'check_violation';
  END IF;

  v_lesson_str := v_s->>'lesson_id';
  IF v_lesson_str !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot lesson_id has invalid UUID format: %', v_lesson_str
      USING ERRCODE = 'check_violation';
  END IF;

  IF jsonb_typeof(v_s->'requirement') != 'object' OR
     jsonb_typeof(v_s->'scope') != 'object' THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot requirement and scope must be JSON objects'
      USING ERRCODE = 'check_violation';
  END IF;

  -- 3. Bind against actual parent content_assignment record
  SELECT lesson_id, requirement, scope, scope_generation
    INTO v_assign_lesson_id, v_assign_req, v_assign_scope, v_assign_gen
    FROM app.content_assignments
   WHERE id = NEW.assignment_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Content assignment % not found', NEW.assignment_id
      USING ERRCODE = 'foreign_key_violation';
  END IF;

  IF v_lesson_str::uuid IS DISTINCT FROM v_assign_lesson_id THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot lesson_id % does not match assignment lesson %',
      v_lesson_str, v_assign_lesson_id
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.scope_generation IS DISTINCT FROM v_assign_gen THEN
    RAISE EXCEPTION 'Assignment history scope_generation % does not match assignment scope_generation %',
      NEW.scope_generation, v_assign_gen
      USING ERRCODE = 'check_violation';
  END IF;

  IF (v_s->'requirement') IS DISTINCT FROM v_assign_req THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot requirement does not match assignment requirement'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (v_s->'scope') IS DISTINCT FROM v_assign_scope THEN
    RAISE EXCEPTION 'Assignment history scope_snapshot scope does not match assignment scope'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assignment_history_scope_snapshot ON app.assignment_history;
CREATE TRIGGER trg_assignment_history_scope_snapshot
  BEFORE INSERT ON app.assignment_history
  FOR EACH ROW EXECUTE FUNCTION app.guard_assignment_history_scope_snapshot();

-- -----------------------------------------------------------------------------
-- Step 3: PRE-01 — Restore Complete Lesson Revision Submitted Payload Guard
-- Preserves complete predecessor submission, monotonic, and freeze logic,
-- adds prior_revision_id and created_at freeze, and preserves permitted lifecycle.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.guard_lesson_revision_submitted_payload()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_has_submit BOOLEAN;
  v_has_core BOOLEAN;
  v_ep_gen BIGINT;
  v_ep_teacher UUID;
  v_ep_snapshot JSONB;
  v_creation_gen BIGINT;
BEGIN
  -- 1. Transition to reviewable / approved / published requires submitted facts, generation, and scope snapshot
  IF NEW.status IN ('IN_REVIEW', 'CHANGES_REQUESTED', 'APPROVED', 'PUBLISHED') THEN
    IF NEW.submitted_at IS NULL OR NEW.submitted_by IS NULL THEN
      RAISE EXCEPTION 'Lesson revision in % status requires nonnull submitted_at and submitted_by', NEW.status
        USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.submitted_assignment_generation IS NULL OR NEW.assignment_scope_snapshot IS NULL THEN
      RAISE EXCEPTION 'Lesson revision in % status requires nonnull submitted_assignment_generation and assignment_scope_snapshot', NEW.status
        USING ERRCODE = 'check_violation';
    END IF;

    -- Validate against actual assignment_history episode
    SELECT scope_generation, next_teacher_id, scope_snapshot
      INTO v_ep_gen, v_ep_teacher, v_ep_snapshot
      FROM app.assignment_history
     WHERE assignment_id = NEW.assignment_id
       AND scope_generation = NEW.submitted_assignment_generation;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Submitted assignment generation % not found in assignment_history for assignment %',
        NEW.submitted_assignment_generation, NEW.assignment_id USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.submitted_by IS DISTINCT FROM v_ep_teacher THEN
      RAISE EXCEPTION 'Submitted_by % does not match assignment episode teacher %',
        NEW.submitted_by, v_ep_teacher USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.assignment_scope_snapshot IS DISTINCT FROM v_ep_snapshot THEN
      RAISE EXCEPTION 'Lesson revision assignment_scope_snapshot does not match assignment episode scope_snapshot'
        USING ERRCODE = 'check_violation';
    END IF;

    SELECT scope_generation INTO v_creation_gen
      FROM app.assignment_history
     WHERE id = NEW.creation_assignment_episode_id;

    IF v_creation_gen IS NOT NULL AND NEW.submitted_assignment_generation < v_creation_gen THEN
      RAISE EXCEPTION 'Submitted assignment generation % cannot be older than creation episode generation %',
        NEW.submitted_assignment_generation, v_creation_gen USING ERRCODE = 'check_violation';
    END IF;

    SELECT EXISTS (
      SELECT 1 FROM app.lesson_exercises
       WHERE lesson_revision_id = NEW.id AND is_core = true
    ) INTO v_has_core;

    IF NOT v_has_core THEN
      RAISE EXCEPTION 'Lesson revision in % status requires at least one core exercise', NEW.status
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- 2. Monotonic submitted_at: once set, cannot be cleared or modified
  IF OLD.submitted_at IS NOT NULL AND (NEW.submitted_at IS NULL OR NEW.submitted_at IS DISTINCT FROM OLD.submitted_at) THEN
    RAISE EXCEPTION 'Lesson revision submitted_at cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;

  -- 3. Monotonic submitted_by: once set, cannot be cleared or changed
  IF OLD.submitted_by IS NOT NULL AND (NEW.submitted_by IS NULL OR NEW.submitted_by IS DISTINCT FROM OLD.submitted_by) THEN
    RAISE EXCEPTION 'Lesson revision submitted_by cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;

  -- 4. Monotonic submitted_assignment_generation
  IF OLD.submitted_assignment_generation IS NOT NULL AND (NEW.submitted_assignment_generation IS NULL OR NEW.submitted_assignment_generation IS DISTINCT FROM OLD.submitted_assignment_generation) THEN
    RAISE EXCEPTION 'Lesson revision submitted_assignment_generation cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;

  -- 5. Monotonic assignment_scope_snapshot
  IF OLD.assignment_scope_snapshot IS NOT NULL AND (NEW.assignment_scope_snapshot IS NULL OR NEW.assignment_scope_snapshot IS DISTINCT FROM OLD.assignment_scope_snapshot) THEN
    RAISE EXCEPTION 'Lesson revision assignment_scope_snapshot cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;

  -- 6. Monotonic approved_at / published_at
  IF OLD.approved_at IS NOT NULL AND (NEW.approved_at IS NULL OR NEW.approved_at IS DISTINCT FROM OLD.approved_at) THEN
    RAISE EXCEPTION 'Lesson revision approved_at cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.published_at IS NOT NULL AND (NEW.published_at IS NULL OR NEW.published_at IS DISTINCT FROM OLD.published_at) THEN
    RAISE EXCEPTION 'Lesson revision published_at cannot be cleared or modified' USING ERRCODE = 'check_violation';
  END IF;

  -- 7. Check if revision was ever submitted
  v_has_submit := (OLD.submitted_at IS NOT NULL) OR (OLD.status IN ('IN_REVIEW', 'CHANGES_REQUESTED', 'APPROVED', 'PUBLISHED')) OR EXISTS (
    SELECT 1 FROM app.revision_reviews
     WHERE lesson_revision_id = OLD.id AND action = 'SUBMIT'
  );

  IF v_has_submit THEN
    IF NEW.status = 'DRAFT' THEN
      RAISE EXCEPTION 'Ever-submitted lesson revision cannot return to DRAFT status' USING ERRCODE = 'check_violation';
    END IF;

    -- Freeze check: all authored payload AND all provenance pins (including prior_revision_id and created_at)
    IF OLD.title IS DISTINCT FROM NEW.title OR
       OLD.content_blocks IS DISTINCT FROM NEW.content_blocks OR
       OLD.topic_ids IS DISTINCT FROM NEW.topic_ids OR
       OLD.skill_ids IS DISTINCT FROM NEW.skill_ids OR
       OLD.purpose_tags IS DISTINCT FROM NEW.purpose_tags OR
       OLD.coverage_catalog_generation IS DISTINCT FROM NEW.coverage_catalog_generation OR
       OLD.coverage_snapshot IS DISTINCT FROM NEW.coverage_snapshot OR
       OLD.prior_revision_id IS DISTINCT FROM NEW.prior_revision_id OR
       OLD.created_at IS DISTINCT FROM NEW.created_at THEN
      RAISE EXCEPTION 'Ever-submitted lesson revision authored payload is frozen' USING ERRCODE = 'check_violation';
    END IF;

    IF OLD.lesson_id IS DISTINCT FROM NEW.lesson_id OR
       OLD.assignment_id IS DISTINCT FROM NEW.assignment_id OR
       OLD.creation_assignment_episode_id IS DISTINCT FROM NEW.creation_assignment_episode_id OR
       OLD.revision_no IS DISTINCT FROM NEW.revision_no OR
       OLD.created_by IS DISTINCT FROM NEW.created_by THEN
      RAISE EXCEPTION 'Lesson revision identity and provenance are immutable' USING ERRCODE = 'check_violation';
    END IF;
  ELSE
    IF OLD.lesson_id IS DISTINCT FROM NEW.lesson_id OR
       OLD.assignment_id IS DISTINCT FROM NEW.assignment_id OR
       OLD.creation_assignment_episode_id IS DISTINCT FROM NEW.creation_assignment_episode_id OR
       OLD.revision_no IS DISTINCT FROM NEW.revision_no OR
       OLD.created_by IS DISTINCT FROM NEW.created_by OR
       OLD.created_at IS DISTINCT FROM NEW.created_at THEN
      RAISE EXCEPTION 'Lesson revision identity fields are immutable' USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_lesson_revision_submitted_payload ON app.lesson_revisions;
CREATE TRIGGER trg_lesson_revision_submitted_payload
  BEFORE UPDATE ON app.lesson_revisions
  FOR EACH ROW EXECUTE FUNCTION app.guard_lesson_revision_submitted_payload();

-- -----------------------------------------------------------------------------
-- Step 4: PRE-03 — Review Provenance, Row Generation/Snapshot Correspondence
-- Validates review-row generation and snapshot against assignment episode,
-- validates assignment envelope with regex protection against incidental 22P02,
-- and enforces strict SUBMIT provenance.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.check_revision_review_provenance()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_lesson_id UUID;
  v_lesson_assign_id UUID;
  v_ep_assign_id UUID;
  v_ep_gen BIGINT;
  v_next_teacher_id UUID;
  v_sub_by UUID;
  v_sub_at TIMESTAMPTZ;
  v_sub_gen BIGINT;
  v_ep_snapshot JSONB;
  v_lr_snapshot JSONB;
  v_version_bp_gen BIGINT;
  v_ver_str TEXT;
  v_lesson_str TEXT;
BEGIN
  IF NEW.lesson_revision_id IS NOT NULL THEN
    IF NEW.assessment_version_id IS NOT NULL THEN
      RAISE EXCEPTION 'Revision review cannot reference both a lesson revision and an assessment version'
        USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.blueprint_generation IS NOT NULL THEN
      RAISE EXCEPTION 'Lesson revision review must have null blueprint_generation'
        USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.assignment_episode_id IS NULL THEN
      RAISE EXCEPTION 'Lesson revision review requires assignment_episode_id'
        USING ERRCODE = 'check_violation';
    END IF;

    SELECT lesson_id, assignment_id, submitted_by, submitted_at, submitted_assignment_generation, assignment_scope_snapshot
      INTO v_lesson_id, v_lesson_assign_id, v_sub_by, v_sub_at, v_sub_gen, v_lr_snapshot
      FROM app.lesson_revisions WHERE id = NEW.lesson_revision_id;

    SELECT assignment_id, scope_generation, next_teacher_id, scope_snapshot
      INTO v_ep_assign_id, v_ep_gen, v_next_teacher_id, v_ep_snapshot
      FROM app.assignment_history WHERE id = NEW.assignment_episode_id;

    IF v_ep_assign_id IS DISTINCT FROM v_lesson_assign_id THEN
      RAISE EXCEPTION 'Review episode assignment % does not match lesson assignment %',
        v_ep_assign_id, v_lesson_assign_id USING ERRCODE = 'check_violation';
    END IF;

    -- Validate NEW review row pins against episode authority
    IF NEW.assignment_generation IS DISTINCT FROM v_ep_gen THEN
      RAISE EXCEPTION 'Review assignment_generation % does not match episode scope_generation %',
        NEW.assignment_generation, v_ep_gen USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.assignment_scope_snapshot IS DISTINCT FROM v_ep_snapshot THEN
      RAISE EXCEPTION 'Review assignment_scope_snapshot does not match episode scope_snapshot'
        USING ERRCODE = 'check_violation';
    END IF;

    -- Validate assignment envelope shape in episode snapshot (PRE-03: safe format checks before cast)
    IF v_ep_snapshot IS NULL OR jsonb_typeof(v_ep_snapshot) != 'object' THEN
      RAISE EXCEPTION 'Assignment scope snapshot must be a JSON object' USING ERRCODE = 'check_violation';
    END IF;

    IF NOT (v_ep_snapshot ? 'schema_version') OR jsonb_typeof(v_ep_snapshot->'schema_version') != 'number' THEN
      RAISE EXCEPTION 'Assignment scope snapshot requires numeric schema_version' USING ERRCODE = 'check_violation';
    END IF;

    v_ver_str := v_ep_snapshot->>'schema_version';
    IF v_ver_str !~ '^[0-9]+$' OR v_ver_str::int != 1 THEN
      RAISE EXCEPTION 'Assignment scope snapshot requires schema_version = 1' USING ERRCODE = 'check_violation';
    END IF;

    IF NOT (v_ep_snapshot ? 'lesson_id') OR jsonb_typeof(v_ep_snapshot->'lesson_id') != 'string' THEN
      RAISE EXCEPTION 'Assignment scope snapshot requires string lesson_id' USING ERRCODE = 'check_violation';
    END IF;

    v_lesson_str := v_ep_snapshot->>'lesson_id';
    IF v_lesson_str !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN
      RAISE EXCEPTION 'Assignment scope snapshot lesson_id has invalid UUID format: %', v_lesson_str
        USING ERRCODE = 'check_violation';
    END IF;

    IF v_lesson_str::uuid IS DISTINCT FROM v_lesson_id THEN
      RAISE EXCEPTION 'Assignment scope snapshot lesson_id % does not match lesson %',
        v_lesson_str, v_lesson_id USING ERRCODE = 'check_violation';
    END IF;

    IF NOT (v_ep_snapshot ? 'requirement') OR jsonb_typeof(v_ep_snapshot->'requirement') != 'object' OR
       NOT (v_ep_snapshot ? 'scope') OR jsonb_typeof(v_ep_snapshot->'scope') != 'object' THEN
      RAISE EXCEPTION 'Assignment scope snapshot requires requirement and scope JSON objects'
        USING ERRCODE = 'check_violation';
    END IF;

    -- If action is SUBMIT, strictly enforce complete submitted provenance
    IF NEW.action = 'SUBMIT' THEN
      IF NEW.actor_id IS DISTINCT FROM v_next_teacher_id THEN
        RAISE EXCEPTION 'SUBMIT review actor % must match episode teacher %',
          NEW.actor_id, v_next_teacher_id USING ERRCODE = 'check_violation';
      END IF;

      IF v_sub_by IS NULL OR v_sub_by IS DISTINCT FROM NEW.actor_id THEN
        RAISE EXCEPTION 'SUBMIT review actor % does not match lesson revision submitted_by %',
          NEW.actor_id, v_sub_by USING ERRCODE = 'check_violation';
      END IF;

      IF v_sub_at IS NULL THEN
        RAISE EXCEPTION 'Lesson revision must have submitted_at timestamp when SUBMIT review is recorded'
          USING ERRCODE = 'check_violation';
      END IF;

      IF v_sub_gen IS NULL OR v_sub_gen IS DISTINCT FROM v_ep_gen THEN
        RAISE EXCEPTION 'Lesson revision submitted_assignment_generation % does not match review episode scope_generation %',
          v_sub_gen, v_ep_gen USING ERRCODE = 'check_violation';
      END IF;

      IF v_lr_snapshot IS NULL OR v_lr_snapshot IS DISTINCT FROM v_ep_snapshot THEN
        RAISE EXCEPTION 'Lesson revision assignment_scope_snapshot does not match review episode scope_snapshot'
          USING ERRCODE = 'check_violation';
      END IF;
    END IF;

  ELSIF NEW.assessment_version_id IS NOT NULL THEN
    IF NEW.lesson_revision_id IS NOT NULL THEN
      RAISE EXCEPTION 'Revision review cannot reference both a lesson revision and an assessment version'
        USING ERRCODE = 'check_violation';
    END IF;

    IF NEW.assignment_episode_id IS NOT NULL OR
       NEW.assignment_generation IS NOT NULL OR
       NEW.assignment_scope_snapshot IS NOT NULL THEN
      RAISE EXCEPTION 'Assessment version review must have null assignment episode pins'
        USING ERRCODE = 'check_violation';
    END IF;

    SELECT blueprint_generation INTO v_version_bp_gen
      FROM app.assessment_versions WHERE id = NEW.assessment_version_id;

    IF v_version_bp_gen IS NULL THEN
      RAISE EXCEPTION 'Assessment version % not found', NEW.assessment_version_id USING ERRCODE = 'foreign_key_violation';
    END IF;

    IF NEW.blueprint_generation IS DISTINCT FROM v_version_bp_gen THEN
      RAISE EXCEPTION 'Review blueprint_generation % does not match assessment version blueprint_generation %',
        NEW.blueprint_generation, v_version_bp_gen USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_revision_review_provenance ON app.revision_reviews;
CREATE TRIGGER trg_revision_review_provenance
  BEFORE INSERT OR UPDATE OF lesson_revision_id, assessment_version_id, assignment_episode_id,
                            assignment_generation, assignment_scope_snapshot, blueprint_generation,
                            action, actor_id ON app.revision_reviews
  FOR EACH ROW EXECUTE FUNCTION app.check_revision_review_provenance();

-- -----------------------------------------------------------------------------
-- Step 5: PRE-03 — Version Envelope, Catalog & Config Snapshot Validation
-- Validates schema_version, config, coverage, requirements, coverage_catalog
-- Enforces regex format validation before casts to avoid incidental 22P02/22003
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.check_assessment_version_snapshot()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_bp_course UUID;
  v_bp_lang UUID;
  v_bp_fw UUID;
  v_bp_purpose TEXT;
  v_bp_target_level UUID;
  v_bp_next_level UUID;
  v_bp_generation BIGINT;
  v_bp_cat_gen BIGINT;
  v_bp_config JSONB;
  v_bp_coverage JSONB;
  v_bp_requirements JSONB;
  v_course_catalog JSONB;
  v_course_cat_gen BIGINT;
  s JSONB := NEW.blueprint_snapshot;
  v_str TEXT;
BEGIN
  IF s IS NULL OR jsonb_typeof(s) != 'object' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot must be a JSON object' USING ERRCODE = 'check_violation';
  END IF;

  -- 1. Envelope key existence: all 14 required keys
  IF NOT (s ? 'schema_version') OR
     NOT (s ? 'blueprint_id') OR
     NOT (s ? 'blueprint_generation') OR
     NOT (s ? 'course_id') OR
     NOT (s ? 'language_id') OR
     NOT (s ? 'framework_id') OR
     NOT (s ? 'purpose') OR
     NOT (s ? 'target_level_id') OR
     NOT (s ? 'next_level_id') OR
     NOT (s ? 'coverage_catalog_generation') OR
     NOT (s ? 'config') OR
     NOT (s ? 'coverage') OR
     NOT (s ? 'requirements') OR
     NOT (s ? 'coverage_catalog') THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot missing required envelope keys (schema_version, blueprint_id, blueprint_generation, course_id, language_id, framework_id, purpose, target_level_id, next_level_id, coverage_catalog_generation, config, coverage, requirements, coverage_catalog)'
      USING ERRCODE = 'check_violation';
  END IF;

  -- 2. Validate types and format BEFORE any cast (PRE-03)
  -- schema_version: must be integer 1
  IF jsonb_typeof(s->'schema_version') != 'number' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot schema_version must be integer 1' USING ERRCODE = 'check_violation';
  END IF;
  v_str := s->>'schema_version';
  IF v_str !~ '^[0-9]+$' OR v_str::int != 1 THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot schema_version must be integer 1' USING ERRCODE = 'check_violation';
  END IF;

  -- UUID identity keys: blueprint_id, course_id, language_id, framework_id
  IF jsonb_typeof(s->'blueprint_id') != 'string' OR
     jsonb_typeof(s->'course_id') != 'string' OR
     jsonb_typeof(s->'language_id') != 'string' OR
     jsonb_typeof(s->'framework_id') != 'string' OR
     jsonb_typeof(s->'purpose') != 'string' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot identity keys must be non-null strings' USING ERRCODE = 'check_violation';
  END IF;

  IF (s->>'blueprint_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' OR
     (s->>'course_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' OR
     (s->>'language_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' OR
     (s->>'framework_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot identity keys must be valid UUID strings' USING ERRCODE = 'check_violation';
  END IF;

  -- generations: must be positive integer strings
  IF jsonb_typeof(s->'blueprint_generation') != 'number' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot blueprint_generation must be positive integer' USING ERRCODE = 'check_violation';
  END IF;
  v_str := s->>'blueprint_generation';
  IF v_str !~ '^[1-9][0-9]*$' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot blueprint_generation must be positive integer' USING ERRCODE = 'check_violation';
  END IF;

  IF jsonb_typeof(s->'coverage_catalog_generation') != 'number' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot coverage_catalog_generation must be positive integer' USING ERRCODE = 'check_violation';
  END IF;
  v_str := s->>'coverage_catalog_generation';
  IF v_str !~ '^[1-9][0-9]*$' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot coverage_catalog_generation must be positive integer' USING ERRCODE = 'check_violation';
  END IF;

  -- nullable level keys: string with UUID format OR null
  IF jsonb_typeof(s->'target_level_id') = 'string' THEN
    IF (s->>'target_level_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN
      RAISE EXCEPTION 'Assessment version blueprint_snapshot target_level_id has invalid UUID format' USING ERRCODE = 'check_violation';
    END IF;
  ELSIF jsonb_typeof(s->'target_level_id') != 'null' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot target_level_id must be UUID string or null' USING ERRCODE = 'check_violation';
  END IF;

  IF jsonb_typeof(s->'next_level_id') = 'string' THEN
    IF (s->>'next_level_id') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN
      RAISE EXCEPTION 'Assessment version blueprint_snapshot next_level_id has invalid UUID format' USING ERRCODE = 'check_violation';
    END IF;
  ELSIF jsonb_typeof(s->'next_level_id') != 'null' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot next_level_id must be UUID string or null' USING ERRCODE = 'check_violation';
  END IF;

  -- config, coverage, requirements, coverage_catalog: must be JSON objects
  IF jsonb_typeof(s->'config') != 'object' OR
     jsonb_typeof(s->'coverage') != 'object' OR
     jsonb_typeof(s->'requirements') != 'object' OR
     jsonb_typeof(s->'coverage_catalog') != 'object' THEN
    RAISE EXCEPTION 'Assessment version blueprint_snapshot config, coverage, requirements, and coverage_catalog must be JSON objects' USING ERRCODE = 'check_violation';
  END IF;

  -- 3. Read and bind against actual blueprint row and parent course
  SELECT bp.course_id, c.language_id, c.framework_id, bp.purpose, bp.target_level_id, bp.next_level_id,
         bp.generation, bp.coverage_catalog_generation, bp.config, bp.coverage, bp.requirements,
         c.coverage_catalog, c.coverage_catalog_generation
    INTO v_bp_course, v_bp_lang, v_bp_fw, v_bp_purpose, v_bp_target_level, v_bp_next_level,
         v_bp_generation, v_bp_cat_gen, v_bp_config, v_bp_coverage, v_bp_requirements,
         v_course_catalog, v_course_cat_gen
    FROM app.assessment_blueprints bp
    JOIN app.courses c ON c.id = bp.course_id
   WHERE bp.id = NEW.blueprint_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Assessment blueprint % not found', NEW.blueprint_id USING ERRCODE = 'foreign_key_violation';
  END IF;

  IF NEW.blueprint_generation IS DISTINCT FROM v_bp_generation THEN
    RAISE EXCEPTION 'Assessment version blueprint_generation % does not match blueprint current generation %',
      NEW.blueprint_generation, v_bp_generation USING ERRCODE = 'check_violation';
  END IF;

  -- 4. Verify scope equality against blueprint source
  IF (s->>'blueprint_id')::UUID IS DISTINCT FROM NEW.blueprint_id OR
     (s->>'blueprint_generation')::BIGINT IS DISTINCT FROM NEW.blueprint_generation OR
     (s->>'course_id')::UUID IS DISTINCT FROM v_bp_course OR
     (s->>'language_id')::UUID IS DISTINCT FROM v_bp_lang OR
     (s->>'framework_id')::UUID IS DISTINCT FROM v_bp_fw OR
     (s->>'purpose') IS DISTINCT FROM v_bp_purpose THEN
    RAISE EXCEPTION 'Assessment version snapshot scope does not match actual blueprint scope'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->>'target_level_id')::UUID IS DISTINCT FROM v_bp_target_level OR
     (s->>'next_level_id')::UUID IS DISTINCT FROM v_bp_next_level THEN
    RAISE EXCEPTION 'Assessment version snapshot target/next levels do not match actual blueprint levels'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->>'coverage_catalog_generation')::BIGINT IS DISTINCT FROM v_bp_cat_gen OR
     (s->>'coverage_catalog_generation')::BIGINT IS DISTINCT FROM v_course_cat_gen THEN
    RAISE EXCEPTION 'Assessment version snapshot coverage_catalog_generation does not match blueprint or course catalog generation'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->'config') IS DISTINCT FROM v_bp_config THEN
    RAISE EXCEPTION 'Assessment version snapshot config does not match blueprint config'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->'coverage') IS DISTINCT FROM v_bp_coverage THEN
    RAISE EXCEPTION 'Assessment version snapshot coverage does not match blueprint coverage'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->'requirements') IS DISTINCT FROM v_bp_requirements THEN
    RAISE EXCEPTION 'Assessment version snapshot requirements do not match blueprint requirements'
      USING ERRCODE = 'check_violation';
  END IF;

  IF (s->'coverage_catalog') IS DISTINCT FROM v_course_catalog THEN
    RAISE EXCEPTION 'Assessment version snapshot coverage_catalog does not match course coverage_catalog'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assessment_version_snapshot_shape ON app.assessment_versions;
CREATE TRIGGER trg_assessment_version_snapshot_shape
  BEFORE INSERT OR UPDATE OF blueprint_snapshot, blueprint_id, blueprint_generation ON app.assessment_versions
  FOR EACH ROW EXECUTE FUNCTION app.check_assessment_version_snapshot();

-- -----------------------------------------------------------------------------
-- Step 6: PRE-02 — Assessment Version Item Eligibility & Coverage Correspondence
-- Retains item blueprint pins check against version blueprint pins,
-- checks review generation against episode scope generation,
-- uses immutable version snapshot for scope matching, and enforces complete
-- coverage_tags 3-array envelope with source lesson dictionary correspondence.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.check_assessment_version_item_eligibility()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_origin TEXT;
  v_omitted BOOLEAN;
  v_frozen TIMESTAMPTZ;
  v_action TEXT;
  v_review_lesson_rev UUID;
  v_review_episode UUID;
  v_review_gen BIGINT;
  v_ep_gen BIGINT;
  v_lesson_submitted TIMESTAMPTZ;
  v_lesson_topic_ids TEXT[];
  v_lesson_skill_ids TEXT[];
  v_lesson_purpose_tags TEXT[];
  v_lesson_course UUID;
  v_lesson_lang UUID;
  v_lesson_fw UUID;
  v_ver_bp_id UUID;
  v_ver_bp_gen BIGINT;
  v_snapshot JSONB;
  v_snap_course UUID;
  v_snap_lang UUID;
  v_snap_fw UUID;
  v_item_bp_id UUID;
  v_item_bp_gen BIGINT;
  v_tags JSONB := NEW.coverage_tags;
  v_elem JSONB;
  v_elem_str TEXT;
BEGIN
  -- 1. Origin check: item identity must have origin ASSESSMENT
  SELECT origin INTO v_origin FROM app.item_identities WHERE id = NEW.item_id;
  IF v_origin IS DISTINCT FROM 'ASSESSMENT' THEN
    RAISE EXCEPTION 'Assessment version item % must have origin ASSESSMENT', NEW.item_id USING ERRCODE = 'check_violation';
  END IF;

  -- 2. Item revision checks: draft-omitted and frozen_at, plus read blueprint pins (PRE-02)
  SELECT is_draft_omitted, frozen_at, assessment_blueprint_id, blueprint_generation
    INTO v_omitted, v_frozen, v_item_bp_id, v_item_bp_gen
    FROM app.item_revisions WHERE id = NEW.item_revision_id;

  IF v_omitted = true THEN
    RAISE EXCEPTION 'Draft-omitted item revision % cannot be included in assessment version', NEW.item_revision_id USING ERRCODE = 'check_violation';
  END IF;
  IF v_frozen IS NULL THEN
    RAISE EXCEPTION 'Unfrozen item revision % cannot be included in assessment version', NEW.item_revision_id USING ERRCODE = 'check_violation';
  END IF;

  -- 3. Source review submission checks
  SELECT action, lesson_revision_id, assignment_episode_id, assignment_generation
    INTO v_action, v_review_lesson_rev, v_review_episode, v_review_gen
    FROM app.revision_reviews WHERE id = NEW.source_submission_id;

  IF v_action IS DISTINCT FROM 'SUBMIT' THEN
    RAISE EXCEPTION 'Source review action must be SUBMIT for assessment version item' USING ERRCODE = 'check_violation';
  END IF;
  IF v_review_lesson_rev IS DISTINCT FROM NEW.source_lesson_revision_id THEN
    RAISE EXCEPTION 'Source review lesson revision does not match source_lesson_revision_id' USING ERRCODE = 'check_violation';
  END IF;
  IF v_review_episode IS DISTINCT FROM NEW.contribution_assignment_episode_id THEN
    RAISE EXCEPTION 'Source review episode does not match contribution_assignment_episode_id' USING ERRCODE = 'check_violation';
  END IF;

  -- 4. Check review assignment_generation against contribution episode scope_generation (PRE-02)
  SELECT scope_generation INTO v_ep_gen
    FROM app.assignment_history WHERE id = NEW.contribution_assignment_episode_id;
  IF v_ep_gen IS DISTINCT FROM v_review_gen THEN
    RAISE EXCEPTION 'Review assignment_generation does not match contribution episode scope_generation' USING ERRCODE = 'check_violation';
  END IF;

  -- 5. Source lesson revision must be submitted, read its authored tags
  SELECT submitted_at, topic_ids, skill_ids, purpose_tags
    INTO v_lesson_submitted, v_lesson_topic_ids, v_lesson_skill_ids, v_lesson_purpose_tags
    FROM app.lesson_revisions WHERE id = NEW.source_lesson_revision_id;

  IF v_lesson_submitted IS NULL THEN
    RAISE EXCEPTION 'Source lesson revision % must be submitted', NEW.source_lesson_revision_id USING ERRCODE = 'check_violation';
  END IF;

  -- 6. Read parent version and its immutable pinned snapshot (PRE-02)
  SELECT blueprint_id, blueprint_generation, blueprint_snapshot
    INTO v_ver_bp_id, v_ver_bp_gen, v_snapshot
    FROM app.assessment_versions WHERE id = NEW.assessment_version_id;

  IF v_snapshot IS NULL OR jsonb_typeof(v_snapshot) != 'object' THEN
    RAISE EXCEPTION 'Assessment version snapshot missing or invalid' USING ERRCODE = 'check_violation';
  END IF;

  -- 7. Tie item blueprint pins to version blueprint identity (PRE-02)
  IF v_item_bp_id IS DISTINCT FROM v_ver_bp_id OR v_item_bp_gen IS DISTINCT FROM v_ver_bp_gen THEN
    RAISE EXCEPTION 'Item revision blueprint pins (% / %) do not match assessment version (% / %)',
      v_item_bp_id, v_item_bp_gen, v_ver_bp_id, v_ver_bp_gen USING ERRCODE = 'check_violation';
  END IF;

  -- 8. Scope matching: lesson curriculum must match pinned snapshot scope
  SELECT u.course_id, c.language_id, c.framework_id
    INTO v_lesson_course, v_lesson_lang, v_lesson_fw
    FROM app.lesson_revisions lr
    JOIN app.lessons l ON l.id = lr.lesson_id
    JOIN app.units u ON u.id = l.unit_id
    JOIN app.courses c ON c.id = u.course_id
   WHERE lr.id = NEW.source_lesson_revision_id;

  v_snap_course := (v_snapshot->>'course_id')::UUID;
  v_snap_lang := (v_snapshot->>'language_id')::UUID;
  v_snap_fw := (v_snapshot->>'framework_id')::UUID;

  IF v_snap_course IS DISTINCT FROM v_lesson_course OR
     v_snap_lang IS DISTINCT FROM v_lesson_lang OR
     v_snap_fw IS DISTINCT FROM v_lesson_fw THEN
    RAISE EXCEPTION 'Item authoring lesson curriculum scope does not match pinned version snapshot scope'
      USING ERRCODE = 'check_violation';
  END IF;

  -- 9. Coverage tags envelope validation (PRE-02)
  -- Must be a JSON object containing all 3 required keys: topic_ids, skill_ids, purpose_tags
  IF v_tags IS NULL OR jsonb_typeof(v_tags) != 'object' THEN
    RAISE EXCEPTION 'Assessment version item coverage_tags must be a JSON object' USING ERRCODE = 'check_violation';
  END IF;

  IF NOT (v_tags ? 'topic_ids') OR NOT (v_tags ? 'skill_ids') OR NOT (v_tags ? 'purpose_tags') THEN
    RAISE EXCEPTION 'Assessment version item coverage_tags must contain topic_ids, skill_ids, and purpose_tags arrays'
      USING ERRCODE = 'check_violation';
  END IF;

  IF jsonb_typeof(v_tags->'topic_ids') != 'array' OR
     jsonb_typeof(v_tags->'skill_ids') != 'array' OR
     jsonb_typeof(v_tags->'purpose_tags') != 'array' THEN
    RAISE EXCEPTION 'Assessment version item coverage_tags topic_ids, skill_ids, and purpose_tags must all be JSON arrays'
      USING ERRCODE = 'check_violation';
  END IF;

  -- Validate array elements are strings and match source lesson coverage
  FOR v_elem IN SELECT * FROM jsonb_array_elements(v_tags->'topic_ids') LOOP
    IF jsonb_typeof(v_elem) != 'string' THEN
      RAISE EXCEPTION 'Assessment version item coverage_tags topic_ids elements must be strings' USING ERRCODE = 'check_violation';
    END IF;
    v_elem_str := v_elem #>> '{}';
    IF array_length(v_lesson_topic_ids, 1) > 0 AND NOT (v_elem_str = ANY(v_lesson_topic_ids)) THEN
      RAISE EXCEPTION 'Coverage tag topic_id % is not present in source lesson topic_ids', v_elem_str USING ERRCODE = 'check_violation';
    END IF;
  END LOOP;

  FOR v_elem IN SELECT * FROM jsonb_array_elements(v_tags->'skill_ids') LOOP
    IF jsonb_typeof(v_elem) != 'string' THEN
      RAISE EXCEPTION 'Assessment version item coverage_tags skill_ids elements must be strings' USING ERRCODE = 'check_violation';
    END IF;
    v_elem_str := v_elem #>> '{}';
    IF array_length(v_lesson_skill_ids, 1) > 0 AND NOT (v_elem_str = ANY(v_lesson_skill_ids)) THEN
      RAISE EXCEPTION 'Coverage tag skill_id % is not present in source lesson skill_ids', v_elem_str USING ERRCODE = 'check_violation';
    END IF;
  END LOOP;

  FOR v_elem IN SELECT * FROM jsonb_array_elements(v_tags->'purpose_tags') LOOP
    IF jsonb_typeof(v_elem) != 'string' THEN
      RAISE EXCEPTION 'Assessment version item coverage_tags purpose_tags elements must be strings' USING ERRCODE = 'check_violation';
    END IF;
    v_elem_str := v_elem #>> '{}';
    IF array_length(v_lesson_purpose_tags, 1) > 0 AND NOT (v_elem_str = ANY(v_lesson_purpose_tags)) THEN
      RAISE EXCEPTION 'Coverage tag purpose_tag % is not present in source lesson purpose_tags', v_elem_str USING ERRCODE = 'check_violation';
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assessment_version_item_eligibility ON app.assessment_version_items;
CREATE TRIGGER trg_assessment_version_item_eligibility
  BEFORE INSERT OR UPDATE ON app.assessment_version_items
  FOR EACH ROW EXECUTE FUNCTION app.check_assessment_version_item_eligibility();

-- -----------------------------------------------------------------------------
-- Step 7: Postflight Assertions
-- -----------------------------------------------------------------------------
DO $$
DECLARE
  v_lr_src TEXT;
  v_rev_src TEXT;
  v_ver_src TEXT;
  v_item_src TEXT;
  v_hist_src TEXT;
BEGIN
  SELECT prosrc INTO v_hist_src FROM pg_proc WHERE proname = 'guard_assignment_history_scope_snapshot' AND pronamespace = 'app'::regnamespace;
  IF v_hist_src NOT LIKE '%schema_version%' OR v_hist_src NOT LIKE '%lesson_id%' THEN
    RAISE EXCEPTION 'Postflight assertion failed: guard_assignment_history_scope_snapshot missing schema_version or lesson_id check';
  END IF;

  SELECT prosrc INTO v_lr_src FROM pg_proc WHERE proname = 'guard_lesson_revision_submitted_payload' AND pronamespace = 'app'::regnamespace;
  IF v_lr_src NOT LIKE '%prior_revision_id%' OR v_lr_src NOT LIKE '%created_at%' OR v_lr_src NOT LIKE '%submitted_assignment_generation%' THEN
    RAISE EXCEPTION 'Postflight assertion failed: guard_lesson_revision_submitted_payload missing prior_revision_id, created_at, or submitted_assignment_generation check';
  END IF;

  SELECT prosrc INTO v_rev_src FROM pg_proc WHERE proname = 'check_revision_review_provenance' AND pronamespace = 'app'::regnamespace;
  IF v_rev_src NOT LIKE '%assignment_generation%' OR v_rev_src NOT LIKE '%assignment_scope_snapshot%' THEN
    RAISE EXCEPTION 'Postflight assertion failed: check_revision_review_provenance missing assignment_generation or assignment_scope_snapshot check';
  END IF;

  SELECT prosrc INTO v_ver_src FROM pg_proc WHERE proname = 'check_assessment_version_snapshot' AND pronamespace = 'app'::regnamespace;
  IF v_ver_src NOT LIKE '%schema_version%' OR v_ver_src NOT LIKE '%coverage_catalog%' THEN
    RAISE EXCEPTION 'Postflight assertion failed: check_assessment_version_snapshot missing schema_version or coverage_catalog check';
  END IF;

  SELECT prosrc INTO v_item_src FROM pg_proc WHERE proname = 'check_assessment_version_item_eligibility' AND pronamespace = 'app'::regnamespace;
  IF v_item_src NOT LIKE '%assessment_blueprint_id%' OR v_item_src NOT LIKE '%coverage_tags%' THEN
    RAISE EXCEPTION 'Postflight assertion failed: check_assessment_version_item_eligibility missing assessment_blueprint_id or coverage_tags check';
  END IF;
END $$;

COMMIT;
